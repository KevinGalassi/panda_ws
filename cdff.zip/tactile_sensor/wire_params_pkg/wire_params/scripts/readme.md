To run plotter.py node, make the file executable by opening a terminal in this folder and digiting the following command:

chmod +x plotter.py


To stop the node, close the "Tactile Map" window.
