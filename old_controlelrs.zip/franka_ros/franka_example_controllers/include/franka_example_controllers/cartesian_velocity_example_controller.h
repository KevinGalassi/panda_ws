// Copyright (c) 2017 Franka Emika GmbH
// Use of this source code is governed by the Apache-2.0 license, see LICENSE
#pragma once

#include <memory>
#include <string>

#include <controller_interface/multi_interface_controller.h>
#include <franka_hw/franka_cartesian_command_interface.h>
#include <franka_hw/franka_state_interface.h>
#include <franka_hw/trigger_rate.h>
#include <hardware_interface/robot_hw.h>
#include <ros/node_handle.h>
#include <ros/time.h>

#include <Eigen/Core>
#include <std_msgs/Float32MultiArray.h>




namespace franka_example_controllers {

class CartesianVelocityExampleController : public controller_interface::MultiInterfaceController<
                                               franka_hw::FrankaVelocityCartesianInterface,
                                               franka_hw::FrankaStateInterface> {
 public:
    bool init(hardware_interface::RobotHW* robot_hardware, ros::NodeHandle& node_handle) override;
    void update(const ros::Time&, const ros::Duration& period) override;
    void starting(const ros::Time&) override;
    void stopping(const ros::Time&) override;

 private:
    franka_hw::FrankaVelocityCartesianInterface* velocity_cartesian_interface;
    std::unique_ptr<franka_hw::FrankaCartesianVelocityHandle> velocity_cartesian_handle;
    
    ros::Duration elapsed_time_ ;
    double publish_rate;
    franka_hw::TriggerRate trigger_publish;
    double last_cmd_time;
    double vel_cmd_timeout;

    Eigen::Matrix<double, 6, 1> last_cart_velocity;
    Eigen::Matrix<double, 6, 1> last_cartesian_acc;
    Eigen::Matrix<double, 6, 1> cartesian_velocity;

    Eigen::Matrix<double, 6, 1> cartesian_acc;
    Eigen::Matrix<double, 6, 1> cartesian_jerk;
    
    ros::Subscriber vel_cmd_sub;    // topic : "/cartesian_velocity_request"
    std_msgs::Float32MultiArray vel_msg;
    void Velocity_callback(const std_msgs::Float32MultiArray& msg);

    // Filter
    Eigen::Matrix<double, 6, 1> vel_filter;
    int filter_size;
    int filter_index;
    std::vector<Eigen::Matrix<double, 6, 1>> VelDataVector;
    Eigen::Matrix<double, 6, 1> MeanMatrix;

    ros::Publisher new_vel_pub;
    ros::Publisher filter_pub;

    std::array<double, 6> command, last_command;

    const double p_dot = 1.700;
    const double p_ddot = 13.0;
    const double p_dddot = 6500.0;

    Eigen::Vector3d scaling_factor;
    double max_scaling_factor;
    


};

}  // namespace franka_example_controllers
